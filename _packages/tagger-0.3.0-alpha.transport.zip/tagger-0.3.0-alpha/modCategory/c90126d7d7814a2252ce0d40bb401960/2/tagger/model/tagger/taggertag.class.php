<?php
/**
 * @package tagger
 */
class TaggerTag extends xPDOSimpleObject {}
?>