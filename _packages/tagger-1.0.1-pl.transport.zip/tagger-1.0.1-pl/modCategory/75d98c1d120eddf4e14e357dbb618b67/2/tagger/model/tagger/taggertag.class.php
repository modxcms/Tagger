<?php
/**
 * @property int $id
 * @property string $tag
 * @property int $group
 *
 * @property TaggerGroup $Group
 * @property TaggerTagResource $Resources
 *
 * @package tagger
 */
class TaggerTag extends xPDOSimpleObject {}
?>