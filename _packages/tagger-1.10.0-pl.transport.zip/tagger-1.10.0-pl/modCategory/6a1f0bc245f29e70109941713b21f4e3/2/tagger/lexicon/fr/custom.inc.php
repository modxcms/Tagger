<?php
/**
 * Custom French Lexicon Entries for Tagger
 *
 * @package tagger
 * @subpackage lexicon
 */
