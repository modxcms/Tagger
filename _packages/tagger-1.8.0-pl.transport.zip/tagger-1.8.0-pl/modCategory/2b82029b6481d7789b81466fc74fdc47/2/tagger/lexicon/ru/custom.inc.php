<?php
/**
 * Custom Russian Lexicon Entries for Tagger
 *
 * @package tagger
 * @subpackage lexicon
 */
