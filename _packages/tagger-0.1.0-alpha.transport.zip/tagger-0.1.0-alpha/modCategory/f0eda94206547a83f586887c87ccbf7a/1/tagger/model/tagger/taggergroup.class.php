<?php
/**
 * @package tagger
 */
class TaggerGroup extends xPDOSimpleObject {}
?>