<?php
/**
 * @package tagger
 */
class TaggerTagResource extends xPDOObject {}
?>