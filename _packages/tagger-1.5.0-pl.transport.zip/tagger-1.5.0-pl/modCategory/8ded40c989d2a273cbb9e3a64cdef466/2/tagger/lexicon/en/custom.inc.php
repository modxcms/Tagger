<?php
/**
 * Custom English Lexicon Entries for Tagger
 *
 * @package tagger
 * @subpackage lexicon
 */
