<?php
/**
 * Custom English Lexicon Entries for Tagger
 *
 * @package tagger
 * @subpackage lexicon
 */

$_lang['tagger.custom'] = 'Custom Lexicons for Tagger';